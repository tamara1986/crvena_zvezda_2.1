A Pen created at CodePen.io. You can find this one at https://codepen.io/miguderp/pen/pbOwXL.

 From a few months ago when I was discovering the full potential of GreenSock GSAP.
An interactive (fake) login form which provides visual feedback to the user.